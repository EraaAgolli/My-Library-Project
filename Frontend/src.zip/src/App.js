import React, { useContext } from "react";
import { BrowserRouter as Router, Routes, Route, BrowserRouter} from "react-router-dom";

import Navbar from "./pages/Navbar";
import Hero from "./pages/Hero";
import Contact from "./pages/ContactPage";
import Review from "./pages/reviewPage";
import Footer from "./pages/Footer";
import BookDetailsPage from "./pages/BookDetailsPage";
import Login from "./pages/Login"; 
import Register from "./pages/Register"; 
import ProtectedRoute from "./api/ProtectedRoute"; 
import { AuthContext, AuthProvider } from "./context/AuthContext";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard from "./pages/UserDashboard";
import ReserveForm from "./pages/ReserveForm";
import LibraryServices from "./pages/LibraryService";
import BookFilter from "./pages/BookShop";
import AboutUs from "./pages/AboutUsPage";
import { WishlistProvider } from "./context/WishlistContext";
import WishlistPage from "./pages/WishlistPage";
import BorrowForm from "./pages/BorrowForm";
import OrderForm from "./pages/OrderForm";
import Cart from "./pages/Cart";
import { CartProvider } from "./context/CartContext";
import ContactPage from "./pages/ContactPage";
import CartPage from "./pages/Cart";
import Home from "./pages/Home";
import BookShop from "./pages/BookShop";
import BookCard from "./pages/BookCard";

function HomePage() {
  return (
    <div>
      
      <section id="home"><Hero /></section>
      <section id="about"><AboutUs/></section>
      <section id="libraryservice"><LibraryServices/></section>
      <section id="reviews"><Review /></section>
      <section id="contact"><Contact /></section>
    </div>
  );
}

function AppRoutes() {
  const { user } = useContext(AuthContext);

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/reserve" element={<ReserveForm/>}/>
      <Route path="/books/:id" element={<BookDetailsPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/about" element={<AboutUs/>}/>
      <Route path="/libraryservice" element={<LibraryServices/>}/>
      <Route path="/wishlist" element={<WishlistPage/>}/>
      <Route path="/borrow" element={<BorrowForm/>}/>
      <Route path="/order" element={<OrderForm/>}/>
      <Route path="/contact" element={<ContactPage/>}/>
      <Route path="/cart" element={<CartPage/>}/>
      <Route path="/home" element={<Home/>}/>
      <Route path="/book-shop" element={<BookShop/>}/>
      <Route path="/book-card" element={<BookCard/>}/>
     
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            {user?.role === "ADMIN" ? <AdminDashboard /> : <UserDashboard />}
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <WishlistProvider>
        <CartProvider>
      <BrowserRouter>
        <Navbar />
        <main>
          <AppRoutes />
        </main>
        <Footer />
      </BrowserRouter>
      </CartProvider>
      </WishlistProvider>
    </AuthProvider>
  );
}

export default App;
