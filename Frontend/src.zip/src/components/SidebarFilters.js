// src/components/SidebarFilters.js
import React from "react";

const SidebarFilters = ({ onFilter }) => {
  return (
    <div className="sidebar-filters">
      <h4>Filters</h4>
      <select onChange={(e) => onFilter("genre", e.target.value)}>
        <option value="">All Genres</option>
        <option value="FICTION">Fiction</option>
        <option value="NONFICTION">Nonfiction</option>
        <option value="SCIENCE">Science</option>
        <option value="HISTORY">History</option>
      </select>
      <select onChange={(e) => onFilter("language", e.target.value)}>
        <option value="">All Languages</option>
        <option value="ENGLISH">English</option>
        <option value="ALBANIAN">Albanian</option>
      </select>
    </div>
  );
};

export default SidebarFilters;
