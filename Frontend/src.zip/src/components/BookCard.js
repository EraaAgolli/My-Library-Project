// src/components/BookCard.js
import React from "react";
import { useCartStore } from "../store/cartStore";

const BookCard = ({ book }) => {
  const addItem = useCartStore((state) => state.addItem);

  return (
    <div className="book-card">
      <img src={book.imageUrl} alt={book.title} />
      <h3>{book.title}</h3>
      <p>{book.author}</p>
      <p>{book.price} €</p>
      <button onClick={() => addItem(book, 1)}>Add to Cart</button>
    </div>
  );
};

export default BookCard;
