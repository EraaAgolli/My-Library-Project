import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:8080/books' });

export const fetchBooks = (params) => API.get('', { params });
export const fetchCategories = () => API.get('/categories');