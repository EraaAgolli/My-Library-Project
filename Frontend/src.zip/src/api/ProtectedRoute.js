// src/components/ProtectedRoute.js
import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const ProtectedRoute = ({ children, role }) => {
  const { user } = useContext(AuthContext);

  if (!user) { return <Navigate to="/login"  replace/>;
}
  // Optionally decode JWT to check role
  // For now, just check presence of token
  return children;
};

export default ProtectedRoute;
