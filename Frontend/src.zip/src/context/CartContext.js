// src/context/CartContext.jsx
import React, { createContext, useState, useEffect, useCallback, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "./AuthContext";

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const { user } = useContext(AuthContext);

  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(false);

  // =========================
  // LOAD CART
  // =========================
  const loadCart = useCallback(async () => {
    if (!user) {
      setCart([]);
      return;
    }

    setLoading(true);
    try {
      const res = await api.get("/cart/me");
      setCart(res.data);
    } catch (err) {
      console.error("Error loading cart:", err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Load cart when user logs in
  useEffect(() => {
    loadCart();
  }, [loadCart]);

  // =========================
  // ADD TO CART
  // =========================
  const addToCart = async (bookId, quantity = 1) => {
    if (!user) {
      console.warn("User must be logged in");
      return false;
    }

    try {
      await api.post(`/cart/add/${bookId}?quantity=${quantity}`);
      await loadCart();
      return true;
    } catch (err) {
      console.error("Error adding to cart:", err);
      return false;
    }
  };

  // =========================
  // REMOVE FROM CART
  // =========================
  const removeFromCart = async (bookId) => {
    try {
      await api.delete(`/cart/remove/${bookId}`);
      await loadCart();
    } catch (err) {
      console.error("Error removing item:", err);
    }
  };

  // =========================
  // UPDATE QUANTITY
  // =========================
  const updateQuantity = async (bookId, quantity) => {
    try {
      await api.put(`/cart/update/${bookId}?quantity=${quantity}`);
      await loadCart();
    } catch (err) {
      console.error("Error updating quantity:", err);
    }
  };

  // =========================
  // CLEAR CART
  // =========================
  const clearCart = async () => {
    try {
      await api.delete("/cart/clear");
      setCart([]);
    } catch (err) {
      console.error("Error clearing cart:", err);
    }
  };

  // =========================
  // DERIVED VALUES
  // =========================
  const cartCount = cart.reduce(
    (total, item) => total + (item.quantity || 0),
    0
  );

  const cartTotal = cart.reduce((total, item) => {
    const price = item.book?.price || 0;
    return total + price * item.quantity;
  }, 0);

  return (
    <CartContext.Provider
      value={{
        cart,
        loading,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        cartTotal,
        loadCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};