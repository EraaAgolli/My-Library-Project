// src/context/WishlistContext.jsx
import React, { createContext, useState, useEffect, useCallback, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "./AuthContext";

export const WishlistContext = createContext();

export const WishlistProvider = ({ children }) => {
  const { user } = useContext(AuthContext);

  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(false);

  // =========================
  // LOAD WISHLIST
  // =========================
  const loadWishlist = useCallback(async () => {
    if (!user) {
      setWishlist([]);
      return;
    }

    setLoading(true);
    try {
      const res = await api.get("/wishlist/me");
      setWishlist(res.data);
    } catch (err) {
      console.error("Error loading wishlist:", err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadWishlist();
  }, [loadWishlist]);

  // =========================
  // ADD TO WISHLIST
  // =========================
  const addToWishlist = async (bookId) => {
    if (!user) {
      console.warn("User must be logged in");
      return false;
    }

    try {
      await api.post(`/wishlist/add/${bookId}`);
      await loadWishlist();
      return true;
    } catch (err) {
      console.error("Error adding to wishlist:", err);
      return false;
    }
  };

  // =========================
  // REMOVE FROM WISHLIST
  // =========================
  const removeFromWishlist = async (bookId) => {
    try {
      await api.delete(`/wishlist/remove/${bookId}`);
      await loadWishlist();
    } catch (err) {
      console.error("Error removing from wishlist:", err);
    }
  };

  // =========================
  // TOGGLE WISHLIST
  // =========================
  const toggleWishlist = async (bookId) => {
    if (isInWishlist(bookId)) {
      await removeFromWishlist(bookId);
    } else {
      await addToWishlist(bookId);
    }
  };

  // =========================
  // CHECK IF BOOK EXISTS
  // =========================
  const isInWishlist = (bookId) => {
    return wishlist.some((item) => item.book?.id === bookId || item.id === bookId);
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        loading,
        addToWishlist,
        removeFromWishlist,
        toggleWishlist,
        isInWishlist,
        wishlistCount: wishlist.length,
        loadWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};
