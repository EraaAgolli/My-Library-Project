// store/cartStore.js
import { create } from "zustand";
import axios from "axios";

export const useCartStore = create((set) => ({
  items: [],
  total: 0,

  fetchCart: async () => {
    const res = await axios.get("/cart");
    set({ items: res.data.items, total: res.data.total });
  },

  addItem: async (bookId, quantity = 1, isBorrow = false) => {
    await axios.post("/cart/add", null, {
      params: { bookId, quantity, isBorrow }
    });
    await useCartStore.getState().fetchCart();
  },

  removeItem: async (bookId) => {
    await axios.delete(`/cart/remove/${bookId}`);
    await useCartStore.getState().fetchCart();
  }
}));
