// pages/CartPage.jsx
import { useCartStore } from "../store/cartStore";
import { useEffect } from "react";

export default function CartPage() {
  const { items, total, fetchCart, removeItem } = useCartStore();

  useEffect(() => { fetchCart(); }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
      {items.map((item) => (
        <div key={item.bookId} className="flex justify-between border-b py-2">
          <span>{item.title} x {item.quantity}</span>
          <span>${item.price * item.quantity}</span>
          <button onClick={() => removeItem(item.bookId)} className="text-red-500">Remove</button>
        </div>
      ))}
      <h3 className="text-xl mt-4">Total: ${total}</h3>
      <button className="bg-blue-600 text-white px-4 py-2 rounded mt-4">Checkout</button>
    </div>
  );
}
