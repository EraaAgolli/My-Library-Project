import React, { useState, useEffect } from "react";
import "./../components/Contact.css";

function Contact() {
  const [faqs, setFaqs] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [status, setStatus] = useState(null);

  // Fetch FAQs from backend
  useEffect(() => {
    fetch("http://localhost:8080/contact/faqs")
      .then((res) => res.json())
      .then((data) => setFaqs(data))
      .catch((err) => console.error("Error fetching FAQs:", err));
  }, []);

  // Handle form input
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Submit form to backend
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:8080/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    })
      .then((res) => res.json())
      .then((data) => {
        setStatus(data.message || "Message sent successfully!");
        setFormData({ name: "", email: "", subject: "", message: "" });
      })
      .catch(() => setStatus("Error sending message. Please try again."));
  };

  return (
    <div className="contact-container">
      {/* Header */}
      <div className="contact-header">
      
        <h3>We'd Love to Hear from You</h3>
        <p>
          Have a question, suggestion, or just want to say hello? Reach out to
          us and we'll get back to you as soon as possible.
        </p>
      </div>

      {/* Contact Section */}
      <div className="contact-grid">
        {/* Left: Info */}
        <div className="contact-info">
  <h4>Get in Touch</h4>
  <div className="info-block">
    <h5><span className="emoji">📍</span> Visit Us</h5>
    <p>123 Book Street<br />Literary Lane<br />Reading City, RC 12345</p>
  </div>
  <div className="info-block">
    <h5><span className="emoji">📞</span> Call Us</h5>
    <p>+1 (565) 123-4567<br />+1 (565) 987-6543</p>
  </div>
  <div className="info-block">
    <h5><span className="emoji">✉️</span> Email Us</h5>
    <p>hello@epochofbooks.com<br />support@epochofbooks.com</p>
  </div>
  <div className="info-block">
    <h5><span className="emoji">⏰</span> Business Hours</h5>
    <p>Mon - Fri: 9AM - 8PM<br />Sat - Sun: 10AM - 6PM</p>
  </div>
</div>


        {/* Right: Form */}
        <div className="contact-form">
          <h4>Send Us a Message</h4>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="subject"
              placeholder="Subject"
              value={formData.subject}
              onChange={handleChange}
              required
            />
            <textarea
              name="message"
              placeholder="Message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              required
            ></textarea>
            <button type="submit">Send Message</button>
          </form>
          {status && <p className="form-status">{status}</p>}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="faq-section">
        <h2>Frequently Asked Questions</h2>
        {faqs.length > 0 ? (
          <div className="faq-grid">
            {faqs.map((faq, index) => (
              <div key={index} className="faq-item">
                <h4>{faq.question}</h4>
                <p>{faq.answer}</p>
              </div>
            ))}
          </div>
        ) : (
          <p>Loading FAQs...</p>
        )}
      </div>
    </div>
  );
}

export default Contact;
