// src/pages/Login.js
import React, { useState, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";
import "./../components/Login.css";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try{
      await login(username, password);
      navigate("/dashboard");
  } catch(err){
    console.error("Login failed:",err.response?.data || err.message);
    alert("Login failed.Please check your credentials.")
    setPassword("");
  }
  };

  return (
    <div className="login-page">
      <div className="login-form-section">
        <form onSubmit={handleSubmit} className="login-form">
          <h2>Sign In</h2>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
          <button type="submit">Sign In</button>
        </form>
      </div>

     <div className="welcome-section">
  <h2>Hello, Explorer!</h2>
  <p>
    Step into a world of stories and ideas. Your next adventure is waiting —
    let’s dive in together.
  </p>
  <a href="/register" className="signup-btn">Create your account today</a>
</div>
</div>
  );
};

export default Login;
