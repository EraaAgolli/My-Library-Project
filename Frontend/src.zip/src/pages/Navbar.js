import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {  FaHeart, FaShoppingCart, FaSearch,FaUserCircle } from "react-icons/fa";
import "./../components/Navbar.css";

function Navbar() {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchType, setSearchType] = useState("title");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/book-filter?query=${encodeURIComponent(searchTerm)}&type=${searchType}`);
      setSearchTerm("");
    }
  };

  return (
    <nav className="navbar-horizontal">
      {/* Logo */}
      <Link to="/" className="logo">EPOCH OF BOOKS</Link>

      {/* Nav Links */}
      <ul className="nav-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/book-filter">Shop</Link></li>
        <li><Link to="/about">About us</Link></li>
        <li><Link to="/libraryservice">Services</Link></li>
        <li><Link to="/contact">Contact</Link></li>
      </ul>

      {/* Search */}
      <form onSubmit={handleSearch} className="nav-search">
        <input
          type="text"
          placeholder={`Search by ${searchType}`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <select
          value={searchType}
          onChange={(e) => setSearchType(e.target.value)}
        >
          <option value="title">Title</option>
          <option value="author">Author</option>
        </select>
        <button type="submit" className="icon-btn">
          <FaSearch />
        </button>
      </form>

      {/* Icons */}
      <div className="icon-group">
        <Link to="/wishlist" className="icon-btn"><FaHeart /></Link>
        <Link to="/cart" className="icon-btn"><FaShoppingCart /></Link>
        <Link to="/account" className="icon-btn"><FaUserCircle /></Link>
        
      </div>
    </nav>
  );
}

export default Navbar;
