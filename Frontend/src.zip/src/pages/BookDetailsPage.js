import React, { useContext, useEffect, useState } from "react";
import { useParams , Link, useNavigate} from "react-router-dom";
import "./../components/BookDetails.css";
import { WishlistContext } from "../context/WishlistContext";


function BookDetailsPage() {
  const { id } = useParams();
  const [book, setBook] = useState(null);

  const { wishlist, toggleWishlist} = useContext(WishlistContext);
  
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBook = async () => {
      const res = await fetch(`http://localhost:8080/books/${id}`);
      const data = await res.json();
      setBook(data);
    };
    fetchBook();
  }, [id]);

  if (!book) return <p>Loading book details...</p>;

  


  return (
    <div className="book-details">
      <div className="book-image">
        {book.imageUrl && <img src={book.imageUrl} alt={book.title} className="book-cover-large" />}
        
      </div>

     <div className="book-info">
  <h2>{book.title}</h2>
  <p><strong>Author:</strong> {book.author}</p>
  <p><strong>Publisher:</strong> {book.publisher}</p>
  <p><strong>Price:</strong> ${book.price}</p>
  <p><strong>Rating:</strong> {"⭐".repeat(Math.round(book.rating))}</p>
  <p><strong>Audience:</strong> {book.audience}</p>
  <p><strong>Language:</strong> {book.language}</p>
  <p><strong>Genre:</strong> {book.genre}</p>
  <p><strong>Available Copies:</strong> {book.availableCopies}</p>
  <p><strong>Description:</strong> {book.description}</p>
</div>


   <div className="details-actions">
  <Link to="/book-filter" className="back-btn">← Back to Books</Link>

 
</div>


    </div>
  );
}

export default BookDetailsPage;


