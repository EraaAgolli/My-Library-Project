// src/pages/Home.js
import React, { useEffect, useState } from "react";
import api from "../api/axios";
import BookCard from "../components/BookCard";
import SidebarFilters from "../components/SidebarFilters";

const Home = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    api.get("/books").then((res) => setBooks(res.data));
  }, []);

  const handleFilter = (type, value) => {
    api.get(`/books/filter?${type}=${value}`).then((res) => setBooks(res.data));
  };

  return (
    <div className="home-page">
      <SidebarFilters onFilter={handleFilter} />
      <div className="book-list">
        {books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  );
};

export default Home;
