import React, { useContext, useEffect, useState } from "react";
import "./../components/UserDashboard.css";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";

const UserDashboard = () => {
  const { user } = useContext(AuthContext);
  const [borrowed, setBorrowed] = useState([]);

  useEffect(() => {
    if (!user) return;
    const fetchBorrowed = async () => {
      try {
        const res = await axios.get(`http://localhost:8080/borrows/user/${user.id}`, {
          headers: { Authorization: `Bearer ${user.token}` }
        });
        setBorrowed(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchBorrowed();
  }, [user]);

  return (
    <div className="dashboard">
      <div className="sidebar">
        <h2>Dashboard</h2>
        <a href="#borrowed">Borrowed Books</a>
        <a href="#wishlist">Wishlist</a>
        <a href="#orders">Orders</a>
      </div>

      <div className="main">
        <section id="welcome" className="card welcome">
          <h2>Welcome, {user?.username || "User"}!</h2>
          <p>Select a section from the left to view details.</p>
        </section>

        <section id="borrowed" className="card">
          <h3>Borrowed Books</h3>
          <ul>
            {borrowed.length === 0 ? <li>No borrowed books yet.</li> :
              borrowed.map(b => (
                <li key={b.id}>
                  {b.book?.title || "Unknown title"} — Due: {b.dueDate} — Status: {b.status}
                </li>
              ))
            }
          </ul>
        </section>
      </div>
    </div>
  );
};

export default UserDashboard;
