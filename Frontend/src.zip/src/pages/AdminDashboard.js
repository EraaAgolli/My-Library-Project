// src/pages/AdminDashboard.js
import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const AdminDashboard = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <div className="dashboard-container">
      <h1>Admin Dashboard</h1>
      {user && user.token ? (
        <>
          <p>Welcome, {user.role}!</p>
          <p>You have admin privileges.</p>
          <button onClick={logout}>Logout</button>
        </>
      ) : (
        <p>Please log in to access the admin dashboard.</p>
      )}
    </div>
  );
};

export default AdminDashboard;

