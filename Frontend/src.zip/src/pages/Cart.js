// src/pages/CartPage.jsx
import React, { useContext } from "react";
import { CartContext } from "../context/CartContext";
import "../components/Cart.css"

function CartPage() {
  const { cart, removeFromCart, clearCart, updateQuantity } = useContext(CartContext);

  if (!cart || cart.length === 0) {
    return <p>Your cart is empty.</p>;
  }

  return (
    <div className="cart-container">
      <h2>Your Cart</h2>
      {cart.map((item) => (
        <div key={item.bookId} className="cart-item">
          <img src={item.imageUrl} alt={item.title} className="cart-cover" />
          <div>
            <h3>{item.title}</h3>
            <p>by {item.author}</p>
            <p>${item.price}</p>
            <div>
              <label>Quantity: </label>
              <input
                type="number"
                value={item.quantity}
                min="1"
                onChange={(e) => updateQuantity(item.bookId, e.target.value)}
              />
            </div>
            <button onClick={() => removeFromCart(item.bookId)}>Remove</button>
          </div>
        </div>
      ))}
      <button onClick={clearCart}>Clear Cart</button>
    </div>
  );
}

export default CartPage;
