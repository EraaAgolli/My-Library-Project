
import { Link } from 'react-router-dom';
import { Star, Heart, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';

export const BookCard = ({ book }) => {
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const inWishlist = isInWishlist(book.id);

  const handleWishlistToggle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (inWishlist) {
      await removeFromWishlist(book.id);
    } else {
      await addToWishlist(book.id);
    }
  };

  const handleAddToCart = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    await addToCart(book.id, 1, false);
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <Star key={i} className= "w-4 h-4 fill-burnt text-burnt" />
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <Star key={i} className="w-4 h-4 fill-burnt/50 text-burnt" />
        );
      } else {
        stars.push(
          <Star key={i} className="w-4 h-4 text-stone-300" />
        );
      }
    }
    return stars;
  };

  return (
    <div 
      className="card-book relative"
      data-testid={`book-card-${book.id}`}
    >
      {/* Wishlist Button */}
      <button
        onClick={handleWishlistToggle}
        className="absolute top-6 right-6 z-10 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-sm hover:bg-white transition-all opacity-0 group-hover:opacity-100\"
        data-testid={`wishlist-toggle-${book.id}`}
      >
        <Heart 
          className={`w-4 h-4 transition-colors ${
            inWishlist ? 'fill-burnt text-burnt' : 'text-charcoal-light'
          }`} 
        />
      </button>

      <Link to={`/book/${book.id}`}>
        {/* Book Cover */}
        <div className="relative overflow-hidden rounded-lg mb-4\">
          <img
            src={book.cover_image}
            alt={book.title}
            className="book-cover w-full\"
            loading="lazy\"
          />
          <span className="category-badge absolute bottom-3 left-3\">
            {book.category}
          </span>
        </div>

        {/* Book Info */}
        <div className="space-y-2\">
          <h3 className="font-heading text-lg font-semibold text-charcoal line-clamp-1 group-hover:text-burnt transition-colors\">
            {book.title}
          </h3>
          <p className="text-sm text-charcoal-light line-clamp-1\">
            {book.author}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-2\">
            <div className="flex items-center gap-0.5\">
              {renderStars(book.rating)}
            </div>
            <span className="text-xs text-charcoal-light\">
              ({book.reviews_count})
            </span>
          </div>

          {/* Price */}
          <div className="flex items-center justify-between pt-2\">
            <div>
              <span className="price-tag font-semibold text-charcoal\">
                ${book.price.toFixed(2)}
              </span>
              {book.is_available_for_borrow && (
                <span className="ml-2 text-xs text-sage\">
                  Borrow: ${book.borrow_price.toFixed(2)}
                </span>
              )}
            </div>
          </div>
        </div>
      </Link>

      {/* Add to Cart Button */}
      <Button
        onClick={handleAddToCart}
        className="w-full mt-4 btn-primary text-sm opacity-0 group-hover:opacity-100 transition-opacity\"
        data-testid={`add-to-cart-${book.id}`}
      >
        <ShoppingCart className="w-4 h-4 mr-2\" />
        Add to Cart
      </Button>
    </div>
  );
};

export default BookCard;
