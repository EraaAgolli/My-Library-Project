// src/components/Footer.js
import React from "react";
import "./../components/Footer.css";
import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope, FaFacebookF, FaTwitter, FaLinkedinIn, FaGithub } from "react-icons/fa";


function Footer() {
  return (
    <footer className="footer-container">
      <div className="footer-wrapper">
        
        {/* Left side: Contact Info */}
        <div className="footer-info">
          <div className="info-item">
            <FaMapMarkerAlt className="icon" />
            <p>21 Revolution Street, Paris, France</p>
          </div>
          <div className="info-item">
            <FaPhoneAlt className="icon" />
            <p>+1 (555) 123-456</p>
          </div>
          <div className="info-item">
            <FaEnvelope className="icon" />
            <p>support@company.com</p>
          </div>
        </div>

        {/* Right side: About + Socials */}
        <div className="footer-about">
          <h3>About Us</h3>
          <p>
            We are committed to delivering innovative solutions and exceptional service. 
            Our mission is to empower communities through technology and design.
          </p>
          <div className="social-icons">
            <a href="#" className="social-icon"><FaFacebookF /></a>
            <a href="#" className="social-icon"><FaTwitter /></a>
            <a href="#" className="social-icon"><FaLinkedinIn /></a>
            <a href="#" className="social-icon"><FaGithub /></a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Company Name. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
