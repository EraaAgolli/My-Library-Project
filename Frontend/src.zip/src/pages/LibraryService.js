import React from "react";
import "./../components/service.css";

function Services() {
  return (
    <div className="services-container">
      {/* Header */}
      <div className="services-header">
        
        <h3>Everything You Need for Your Reading Journey</h3>
        <p>
          From buying and borrowing to gifting and exchanging, we offer
          comprehensive services to make your book-loving experience seamless
          and enjoyable.
        </p>
      </div>

      {/* Service Cards */}
      <div className="services-grid">
        <div className="service-card">
          <div className="service-icon">🛒</div>
          <h4>Buy Books</h4>
          <p>Purchase from our vast collection of over 10,000 titles.</p>
          <ul>
            <li>Free shipping over $25</li>
            <li>Gift wrapping available</li>
            <li>Quality guaranteed</li>
          </ul>
        </div>

        <div className="service-card">
          <div className="service-icon">📖</div>
          <h4>Borrow Books</h4>
          <p>Borrow books at a fraction of the price with our rental program.</p>
          <ul>
            <li>14-day rental period</li>
            <li>Extend anytime</li>
            <li>Easy returns</li>
          </ul>
        </div>

        <div className="service-card">
          <div className="service-icon">🎁</div>
          <h4>Gift Cards</h4>
          <p>Give the gift of reading with flexible gift cards.</p>
          <ul>
            <li>Any amount</li>
            <li>Never expires</li>
            <li>Digital or physical</li>
          </ul>
        </div>

        <div className="service-card">
          <div className="service-icon">⚡</div>
          <h4>Express Delivery</h4>
          <p>Need your books fast? Choose express delivery.</p>
          <ul>
            <li>Next-day delivery</li>
            <li>Real-time tracking</li>
            <li>Signature confirmation</li>
          </ul>
        </div>

        <div className="service-card">
          <div className="service-icon">🔄</div>
          <h4>Book Exchange</h4>
          <p>Trade your finished books for store credit.</p>
          <ul>
            <li>Fair valuations</li>
            <li>Instant credit</li>
            <li>Eco-friendly</li>
          </ul>
        </div>

        <div className="service-card">
          <div className="service-icon">💬</div>
          <h4>Customer Support</h4>
          <p>Our dedicated team is here to help anytime.</p>
          <ul>
            <li>24/7 availability</li>
            <li>Expert book advisors</li>
            <li>Quick response</li>
          </ul>
        </div>
      </div>

      {/* Membership Program */}
      <div className="membership-section">
        <div className="membership-content">
          <h2>Coming Soon</h2>
          <h3>Epoch Membership Program</h3>
          <p>
            Join our upcoming membership program and enjoy exclusive benefits
            designed for passionate readers.
          </p>
          <ul>
            <li>Unlimited borrowing</li>
            <li>Early access to new releases</li>
            <li>20% off all purchases</li>
            <li>Free express shipping</li>
            <li>Personalized recommendations</li>
          </ul>
        </div>
        <div className="membership-image">
          <img
            src={require("./../assets/booksStack.png")}
            alt="Membership Program"
          />
        </div>
      </div>
    </div>
  );
}

export default Services;
