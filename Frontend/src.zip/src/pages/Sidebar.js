import React, { useEffect, useState } from 'react';
import { fetchCategories } from './../api/api';

const Sidebar = ({ filters, setFilters }) => {
  const categories = ["Children", "Classic", "Fantasy", "Fiction", "Finance", "History", "Memoir", "Self-Help"];

  const handleUpdate = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="p-8">
      <section className="mb-10">
        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-900 mb-4">Filter Books</h3>
        <input 
          type="text"
          placeholder="Search by title or author..."
          className="w-full px-4 py-3 bg-gray-50 border-none rounded-lg text-sm focus:ring-2 focus:ring-orange-100 transition-all"
          onChange={(e) => handleUpdate('search', e.target.value)}
        />
      </section>

      <section className="mb-10">
        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-900 mb-4 flex justify-between">
          Categories <span>^</span>
        </h3>
        <div className="space-y-3">
          {categories.map(cat => (
            <label key={cat} className="flex items-center group cursor-pointer">
              <input 
                type="radio" 
                name="category" 
                className="w-4 h-4 border-gray-300 text-orange-600 focus:ring-orange-500 mr-3"
                onChange={() => handleUpdate('category', cat)}
              />
              <span className="text-gray-500 group-hover:text-black text-sm transition-colors">{cat}</span>
            </label>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-900 mb-4 flex justify-between">
          Price Range <span>^</span>
        </h3>
        <input 
          type="range" 
          min="0" max="50" 
          className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-orange-600"
          onChange={(e) => handleUpdate('maxPrice', e.target.value)}
        />
        <div className="flex justify-between mt-2 text-xs font-bold text-gray-400 uppercase tracking-tighter">
          <span>$0</span>
          <span>$50</span>
        </div>
      </section>
    </div>
  );
};

export default Sidebar;