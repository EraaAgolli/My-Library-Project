import React from "react";
import "./../components/About.css";
import bertrandBookstore from "./../assets/bertrand-bookstore.jpg";

function AboutUs() {
  return (
    <div className="about-container">
      {/* Intro Section */}
<section className="intro-with-stats">
  <div className="intro-grid">
    {/* Image */}
    <div className="intro-image-wrapper">
      <img
        src={bertrandBookstore}
        alt="Bookstore"
        className="intro-image"
      />
    </div>

    {/* Text + Stats */}
    <div className="intro-text">
      <h2>Our Story Began with a Love for Books</h2>
      <p>
        Founded in 2020, Epoch of Books was born from a simple idea: make great
        literature accessible to everyone. What started as a small online bookstore
        has grown into a vibrant community of readers from around the world.
      </p>
      <p>
        We believe that every book has the power to transform lives, spark imagination,
        and connect people across cultures and generations. Our mission is to curate
        the finest collection of books and deliver them to your doorstep with care
        and passion.
      </p>

      {/* Stats Section right after the photo */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">🕰️</div>
          <p className="stat-value">4+</p>
          <p className="stat-label">Years of Service</p>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📖</div>
          <p className="stat-value">10,000+</p>
          <p className="stat-label">Books Available</p>
        </div>
        <div className="stat-card">
          <div className="stat-icon">😊</div>
          <p className="stat-value">50,000+</p>
          <p className="stat-label">Happy Readers</p>
        </div>
      
      </div>
    </div>
  </div>
</section>


<section className="values-section">
  <div className="values-header">
    <h2>OUR VALUES</h2>
    <h3>What We Stand For</h3>
  </div>
  <div className="values-grid">
    <div className="value-card">
      <div className="icon-circle">📖</div>
      <h4>Quality Selection</h4>
      <p>Every book in our collection is carefully curated by our expert team.</p>
    </div>
    <div className="value-card">
      <div className="icon-circle">👥</div>
      <h4>Community First</h4>
      <p>We foster a community where readers can connect and share their love for books.</p>
    </div>
    <div className="value-card">
      <div className="icon-circle">🏅</div>
      <h4>Excellence</h4>
      <p>We strive for excellence in everything we do, from selection to delivery.</p>
    </div>
    <div className="value-card">
      <div className="icon-circle">🌍</div>
      <h4>Accessibility</h4>
      <p>Making great literature accessible to readers worldwide, regardless of location.</p>
    </div>
  </div>
</section>

   


    </div>
  );
}

export default AboutUs;
